# LINA ESTETIKA — website (iteration 1: homepage)

Slovak homepage for LINA ESTETIKA, aesthetic medicine in Senec.
Only `/` is built. Future routes (`/damy`, `/pani`, `/osetrenia`, `/cennik`, `/vysledky`, `/kontakt`) are **not** created yet.

## Stack

- Next.js 16 (App Router, Turbopack) · React 19 · TypeScript 6
- Tailwind CSS 4 (CSS-first tokens in `src/app/globals.css`)
- GSAP 3 + ScrollTrigger + SplitText, via `@gsap/react` (`useGSAP` → automatic cleanup)
- Lenis smooth scroll, driven by the GSAP ticker (one RAF loop), synced with ScrollTrigger
- Local fonts via `next/font/local` — ITC Avant Garde Gothic Pro (XLight 200, XLight Oblique, Book 400, Book Oblique, Medium 500, Demi 600, Bold 700)

```powershell
npm install
npm run dev        # http://localhost:3000
npm run build
npm run lint
npm run typecheck
```

## Structure

```
src/
├── app/            layout (metadata, JSON-LD, fonts), page, globals.css (design tokens)
├── config/site.ts  ← bookingUrl, address, opening hours, domain
├── data/           treatments, signature concepts, images (+ licensing), navigation
├── lib/            fonts, scroll helper (Lenis-aware), cn
└── components/
    ├── layout/     Header, Footer
    ├── home/       Hero, TreatmentFinder, Treatments, Signature, Approach, Contact, HomeProvider
    ├── motion/     gsap registration + motion tokens, SmoothScroll, SplitText, Reveal, Parallax
    └── ui/         BookingButton, BookingNotice, Eyebrow, Logo, TextLink, icons, buttonStyles
```

## Design system (summary)

| Token | Value |
|---|---|
| Primary | `#D84557` — CTAs, active states, small accents |
| Secondary | `#FFC2A0` (+ tint `#FFF4EE` for the Signature section) |
| Background / text | `#FFFFFF` / `#242424` |
| Neutrals | `#F7F7F7`, `#F2F2F2`, `#E8E8E8`, `#6B6B6B` |
| Content width | 1300px max, gutter `clamp(20px, 4vw, 40px)` |
| Section spacing | `clamp(56px, 7vw, 96px)` |
| Type | H1 34→56px XLight · H2 28→40px XLight + Medium emphasis · cards 19px Medium · body 16px Book |
| Radii | 10 / 16 / 20 / 24px |

Motion: expo/power3 ease-outs, one reveal per block, nothing loops. All GSAP work runs inside
`gsap.matchMedia("(prefers-reduced-motion: no-preference)")`; Lenis is not started for reduced-motion users.

## Booking (Bookio only)

Set `bookingUrl` in `src/config/site.ts`. Every "Rezervovať termín" button reads it.
While it is empty, the buttons stay `<button>` elements that show an accessible notice
("Online rezervácia sa pripravuje") instead of navigating anywhere.

## React Bits

Two components were adapted (not installed) from [React Bits](https://reactbits.dev) and toned down:
- `SplitText` → `components/motion/SplitText.tsx` (masked line reveal for headings)
- `AnimatedContent` → `components/motion/Reveal.tsx` (scroll reveal with optional stagger)

React Bits is distributed under MIT + Commons Clause. Using adapted components inside a client website is fine;
reselling the components themselves is not.

## Image credits (temporary editorial photography)

All from Unsplash, [Unsplash License](https://unsplash.com/license) (free commercial use, attribution not required).
They are **illustrative models**, not clients, staff or results. The footer states "Fotografie na webe sú ilustračné."
Served via `next/image` from `images.unsplash.com` (see `next.config.ts`).

| Key | Used in | Source |
|---|---|---|
| portraitWoman | Hero · Tvár | https://unsplash.com/photos/woman-with-auburn-hair-and-freckles-FODRyogbNU0 |
| neck | Hero · Krk a dekolt | https://unsplash.com/photos/person-with-gold-ring-on-neck-5KY5LP_zc44 |
| body | Hero · Telo | https://unsplash.com/photos/a-close-up-of-a-woman-with-her-hand-on-her-face-afCb20VQqL8 |
| hands | Hero · Ruky | https://unsplash.com/photos/a-close-up-of-a-hand-HHbv5XIj2QA |
| portraitMan | Treatments tile | https://unsplash.com/photos/topless-man-covering-his-face-with-his-hand-8ft43psAJN8 |
| eyes | Signature 01 | https://unsplash.com/photos/close-up-photo-of-persons-eye-fvInY-Gh7sc |
| lips | Signature 02 | https://unsplash.com/photos/young-woman-with-flower-crown-touches-her-lips-with-grass-7mDssWTpBuA |
| decollete | Signature 03 | https://unsplash.com/photos/woman-in-black-tank-top-Sfs21Re13BU |
| profile | Náš prístup | https://unsplash.com/photos/a-woman-with-a-ponytail-is-posing-for-a-picture-k8AWNNCry-0 |

## Open items before launch

1. **Bookio URL** → `siteConfig.bookingUrl`.
2. **Domain** → `siteConfig.url` (turns on `metadataBase`, canonical URL and the URL in JSON-LD).
3. **Phone / e-mail** — not shown; add to `siteConfig` when available.
4. **Photography** — replace the Unsplash images with the client's own photography, or download and self-host licensed files.
   The lips image (Signature 02) has the weakest fit and should be replaced first.
5. **Results gallery and reviews** — deliberately omitted. They need publishing consent, confirmed matching before/after pairs,
   non-identifiable crops and genuine Bookio reviews. The 10 photos in `public/images/client/pery-linaestetika (*)` are unused.
6. **Copy review** — all treatment wording in `src/data/*.ts` is conservative and should be approved by the client / responsible physician.
7. **Font licence** — the `.otf` files sit in `/public/fonts` and are therefore publicly downloadable. If the licence does not allow that,
   move them to e.g. `src/fonts/` (only `src/lib/fonts.ts` needs updating) so only the optimised `next/font` output is served.
8. **Contrast note** — white text on `#D84557` is 4.3:1 (passes AA for large text and UI components, just under 4.5:1 for small text).
   Small text uses ink colour; if strict AA for button labels is required, consider a slightly deeper CTA shade.
9. **Favicon** — `src/app/icon.svg` is a simple placeholder; replace with an icon derived from the logo.
