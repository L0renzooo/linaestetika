import { images, type SiteImage } from "./images";

/** LINA Signature — personalised treatment concepts (not fixed protocols). */
export type SignatureConcept = {
  id: string;
  number: string;
  title: string;
  description: string;
  image: SiteImage;
};

export const signatureConcepts: SignatureConcept[] = [
  {
    id: "rozziareny-pohlad",
    number: "01",
    title: "Rozžiarený pohľad",
    description:
      "Jemná starostlivosť o očné okolie zameraná na regeneráciu pokožky, zlepšenie jej kvality a sviežejší, oddýchnutejší vzhľad.",
    image: images.eyes,
  },
  {
    id: "stavnate-pery",
    number: "02",
    title: "Šťavnaté pery",
    description:
      "Starostlivosť zameraná na hydratáciu, prirodzené kontúry pier a sviežosť ich okolia. S dôrazom na harmonický vzhľad, ktorý ladí s vašou tvárou.",
    image: images.lips,
  },
  {
    id: "krk-dekolt",
    number: "03",
    title: "Sviežosť krku a dekoltu",
    description:
      "Individuálne ošetrenie zamerané na regeneráciu, pružnosť a zlepšenie vzhľadu pokožky krku a dekoltu.",
    image: images.decollete,
  },
];
