"use client";

import { useRef } from "react";
import { gsap, motion, useGSAP } from "@/components/motion/gsap";
import { SplitText } from "@/components/motion/SplitText";
import { BookingButton } from "@/components/ui/BookingButton";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { TextLink } from "@/components/ui/TextLink";
import { ArrowDownIcon } from "@/components/ui/icons";
import { TreatmentFinder } from "./TreatmentFinder";

export function Hero() {
  const ref = useRef<HTMLElement>(null);

  useGSAP(
    () => {
      const mm = gsap.matchMedia();
      mm.add(motion.allowMotion, () => {
        const tl = gsap.timeline({ defaults: { ease: motion.ease } });
        tl.fromTo("[data-hero-item]", { autoAlpha: 0, y: 18 }, { autoAlpha: 1, y: 0, duration: 0.9, stagger: 0.1, clearProps: "transform" }, 0.25)
          .fromTo(
            "[data-hero-media]",
            { clipPath: "inset(6% 4% 0% 4% round 20px)" },
            { clipPath: "inset(0% 0% 0% 0% round 20px)", duration: 1.6, ease: motion.easeExpo, clearProps: "clipPath" },
            0.35,
          )
          .fromTo("[data-hero-media-inner]", { scale: 1.1 }, { scale: 1, duration: 1.8, ease: motion.easeExpo, clearProps: "transform" }, 0.35)
          .fromTo(
            "[data-hero-panel]",
            { autoAlpha: 0, y: 24 },
            { autoAlpha: 1, y: 0, duration: 1, clearProps: "transform" },
            0.6,
          );
      });
    },
    { scope: ref },
  );

  return (
    <section
      ref={ref}
      id="uvod"
      aria-labelledby="hero-title"
      className="pt-[calc(var(--header-h)+1.75rem)] pb-[var(--section-y)] lg:pt-[calc(var(--header-h)+3rem)]"
    >
      <div className="container-site">
        <div className="grid gap-x-10 gap-y-5 pb-7 lg:grid-cols-12 lg:items-end lg:pb-10">
          <div className="lg:col-span-7">
            <div data-hero-item data-reveal="self">
              <Eyebrow>Estetická medicína · Senec</Eyebrow>
            </div>
            <SplitText as="h1" id="hero-title" trigger="load" delay={0.15} className="type-display mt-5">
              Krása, ktorá zostáva <em className="font-extralight text-primary italic">prirodzená.</em>
            </SplitText>
          </div>
          <div className="lg:col-span-5 lg:pb-1">
            <p data-hero-item data-reveal="self" className="max-w-[460px] text-lead text-muted">
              Moderná estetická starostlivosť s dôrazom na kvalitu pokožky, prirodzené výsledky a individuálny prístup.
            </p>
            <div data-hero-item data-reveal="self" className="mt-6 flex flex-wrap items-center gap-x-7 gap-y-3">
              <BookingButton />
              <TextLink href="#osetrenia" icon={<ArrowDownIcon className="size-4" />}>
                Objaviť ošetrenia
              </TextLink>
            </div>
          </div>
        </div>

        <TreatmentFinder />
      </div>
    </section>
  );
}
