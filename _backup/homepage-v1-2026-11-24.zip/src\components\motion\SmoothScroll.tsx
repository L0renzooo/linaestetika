"use client";

import { useEffect } from "react";
import Lenis from "lenis";
import { gsap, ScrollTrigger } from "./gsap";
import { scrollToTarget, setLenis } from "@/lib/scroll";

/**
 * Lenis smooth scrolling, driven by GSAP's ticker (single RAF loop) and
 * synced with ScrollTrigger. Disabled entirely for reduced-motion users.
 * Touch devices keep native scrolling (syncTouch: false).
 *
 * Also handles in-page anchor links so they respect the fixed header
 * and work identically with or without Lenis.
 */
export function SmoothScroll() {
  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)");
    let lenis: Lenis | null = null;
    let tick: ((time: number) => void) | null = null;

    const start = () => {
      if (lenis || reduce.matches) return;
      lenis = new Lenis({
        lerp: 0.11,
        smoothWheel: true,
        syncTouch: false,
        autoRaf: false,
        anchors: false,
      });
      setLenis(lenis);
      lenis.on("scroll", ScrollTrigger.update);
      tick = (time: number) => lenis?.raf(time * 1000);
      gsap.ticker.add(tick);
      gsap.ticker.lagSmoothing(0);
    };

    const stop = () => {
      if (tick) gsap.ticker.remove(tick);
      tick = null;
      lenis?.destroy();
      lenis = null;
      setLenis(null);
      gsap.ticker.lagSmoothing(500, 33);
    };

    const onPreferenceChange = () => (reduce.matches ? stop() : start());

    const onClick = (event: MouseEvent) => {
      if (event.defaultPrevented || event.button !== 0) return;
      if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      const link = (event.target as Element | null)?.closest<HTMLAnchorElement>('a[href^="#"]');
      if (!link) return;
      const id = decodeURIComponent(link.getAttribute("href")!.slice(1));
      if (!id) {
        event.preventDefault();
        if (lenis) lenis.scrollTo(0);
        else window.scrollTo({ top: 0, behavior: reduce.matches ? "auto" : "smooth" });
        history.pushState(null, "", window.location.pathname);
        return;
      }
      const target = document.getElementById(id);
      if (!target) return;
      event.preventDefault();
      scrollToTarget(target);
      history.pushState(null, "", `#${id}`);
    };

    start();
    reduce.addEventListener("change", onPreferenceChange);
    document.addEventListener("click", onClick);

    return () => {
      reduce.removeEventListener("change", onPreferenceChange);
      document.removeEventListener("click", onClick);
      stop();
    };
  }, []);

  return null;
}
