import { images, type SiteImage } from "./images";

/* ------------------------------------------------------------------
   Treatment data — single source of truth for the homepage overview,
   the hero treatment finder and (later) the /osetrenia subpages.
   Wording is intentionally conservative so the client can review it.
------------------------------------------------------------------- */

export type AreaId = "tvar" | "dekolt" | "telo" | "ruky";

export type Area = {
  id: AreaId;
  label: string;
  /** Compact label for tabs / chips. */
  shortLabel: string;
  /** Short line shown in the hero finder. */
  intro: string;
  image: SiteImage;
};

export const areas: Area[] = [
  {
    id: "tvar",
    label: "Tvár",
    shortLabel: "Tvár",
    intro: "Kvalita pleti, hydratácia, mimické vrásky a kontúry tváre.",
    image: images.portraitWoman,
  },
  {
    id: "dekolt",
    label: "Krk a dekolt",
    shortLabel: "Dekolt",
    intro: "Regenerácia a pružnosť pokožky v citlivej oblasti krku a dekoltu.",
    image: images.neck,
  },
  {
    id: "telo",
    label: "Telo",
    shortLabel: "Telo",
    intro: "Kvalita pokožky tela a cielené ošetrenia funkčných ťažkostí.",
    image: images.body,
  },
  {
    id: "ruky",
    label: "Ruky",
    shortLabel: "Ruky",
    intro: "Pokožka horných častí paží a nadmerné potenie dlaní.",
    image: images.hands,
  },
];

export type TreatmentGroup = {
  id: string;
  title: string;
  description: string;
  areas: AreaId[];
  /** Label above the list — "Ošetrenia" or "Oblasti" etc. */
  listLabel: string;
  items: string[];
  note?: string;
};

export const treatmentGroups: TreatmentGroup[] = [
  {
    id: "hydratacia-pleti",
    title: "Hydratácia a žiarivosť pleti",
    description: "Hĺbková hydratácia, rozžiarenie pleti a prevencia predčasného starnutia.",
    areas: ["tvar"],
    listLabel: "Ošetrenia",
    items: [
      "Polynukleotidy",
      "Kyselina hyalurónová a aminokyseliny",
      "Profhilo",
      "Profhilo Structura",
      "Sculptra Glow Protocol",
    ],
  },
  {
    id: "mimicke-vrasky",
    title: "Mimické vrásky",
    description:
      "Zjemnenie vzhľadu mimických vrások s ohľadom na zachovanie prirodzeného výrazu tváre.",
    areas: ["tvar"],
    listLabel: "Ošetrenie",
    items: ["Botulotoxín"],
  },
  {
    id: "pevnost-kontury",
    title: "Pevnosť a kontúry tváre",
    description:
      "Podpora tvorby kolagénu pre postupné zlepšenie vzhľadu pevnosti pleti a kontúr tváre.",
    areas: ["tvar"],
    listLabel: "Ošetrenie",
    items: ["Sculptra Lifting Protocol"],
  },
  {
    id: "krk-dekolt",
    title: "Krk a dekolt",
    description:
      "Individuálne ošetrenia pri strate pružnosti a ochabnutom vzhľade pokožky krku a dekoltu.",
    areas: ["dekolt"],
    listLabel: "Zameranie",
    items: ["Regenerácia pokožky", "Kvalita pokožky", "Pružnosť", "Omladenie vzhľadu"],
  },
  {
    id: "profhilo-body",
    title: "Kvalita pokožky tela",
    description: "Profhilo BODY pre zlepšenie kvality pokožky vo vhodných oblastiach tela.",
    areas: ["telo", "ruky"],
    listLabel: "Oblasti",
    items: ["Paže", "Okolie pupka", "Oblasť nad kolenami"],
  },
  {
    id: "potenie-bruxizmus",
    title: "Potenie a bruxizmus",
    description:
      "Botulotoxín pri nadmernom potení a po lekárskom posúdení aj pri nadmernom napätí žuvacích svalov.",
    areas: ["telo", "ruky"],
    listLabel: "Oblasti",
    items: ["Podpazušie", "Dlane", "Chodidlá", "Žuvacie svaly"],
  },
];

/* ------------------------------------------------------------------
   Hero finder entries — what a visitor sees after choosing an area.
------------------------------------------------------------------- */

export type FinderEntry =
  | { kind: "group"; groupId: string; title: string; detail: string }
  | { kind: "signature"; signatureId: string; title: string; detail: string };

export const finderEntries: Record<AreaId, FinderEntry[]> = {
  tvar: [
    { kind: "group", groupId: "hydratacia-pleti", title: "Hydratácia a žiarivosť pleti", detail: "Profhilo, polynukleotidy, Sculptra Glow" },
    { kind: "group", groupId: "mimicke-vrasky", title: "Mimické vrásky", detail: "Botulotoxín" },
    { kind: "group", groupId: "pevnost-kontury", title: "Pevnosť a kontúry", detail: "Sculptra Lifting Protocol" },
    { kind: "signature", signatureId: "rozziareny-pohlad", title: "Rozžiarený pohľad", detail: "LINA Signature" },
    { kind: "signature", signatureId: "stavnate-pery", title: "Šťavnaté pery", detail: "LINA Signature" },
  ],
  dekolt: [
    { kind: "group", groupId: "krk-dekolt", title: "Regenerácia krku a dekoltu", detail: "Kvalita a pružnosť pokožky" },
    { kind: "signature", signatureId: "krk-dekolt", title: "Sviežosť krku a dekoltu", detail: "LINA Signature" },
  ],
  telo: [
    { kind: "group", groupId: "profhilo-body", title: "Profhilo BODY", detail: "Okolie pupka, oblasť nad kolenami" },
    { kind: "group", groupId: "potenie-bruxizmus", title: "Nadmerné potenie", detail: "Podpazušie, chodidlá" },
    { kind: "group", groupId: "potenie-bruxizmus", title: "Bruxizmus", detail: "Po lekárskom posúdení" },
  ],
  ruky: [
    { kind: "group", groupId: "profhilo-body", title: "Profhilo BODY — paže", detail: "Kvalita pokožky horných častí paží" },
    { kind: "group", groupId: "potenie-bruxizmus", title: "Potenie dlaní", detail: "Botulotoxín" },
  ],
};
