"use client";

import Image from "next/image";
import { signatureConcepts } from "@/data/signature";
import { Reveal } from "@/components/motion/Reveal";
import { SplitText } from "@/components/motion/SplitText";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { useHome } from "./HomeProvider";
import { cn } from "@/lib/cn";

/**
 * LINA Signature — three personalised concepts in one compact composition.
 * Desktop: expanding image panels (hover / focus / click).
 * Tablet & mobile: a horizontal snap rail with all text visible.
 */
export function Signature() {
  const { activeSignature, setActiveSignature } = useHome();

  return (
    <section id="signature" aria-labelledby="signature-title" className="section-y relative bg-peach-soft">
      <div className="container-site">
        <header className="grid gap-x-10 gap-y-5 lg:grid-cols-12 lg:items-end">
          <div className="lg:col-span-7">
            <Reveal>
              <Eyebrow>LINA Signature</Eyebrow>
            </Reveal>
            <SplitText as="h2" id="signature-title" className="type-h2 mt-4">
              Individuálna starostlivosť <em className="font-extralight italic">šitá na mieru</em>
            </SplitText>
          </div>
          <Reveal className="lg:col-span-5">
            <p className="max-w-[480px] text-muted">
              Každá pokožka má svoje potreby. Preto ku každému ošetreniu pristupujeme individuálne — s dôrazom na
              prirodzenosť, rovnováhu a výsledok, ktorý rešpektuje vaše črty.
            </p>
          </Reveal>
        </header>

        <Reveal
          as="ul"
          mode="items"
          stagger={0.1}
          className="no-scrollbar -mx-[var(--gutter)] mt-9 flex snap-x snap-mandatory gap-3 overflow-x-auto scroll-px-[var(--gutter)] px-[var(--gutter)] lg:mx-0 lg:mt-12 lg:h-[500px] lg:gap-4 lg:overflow-visible lg:px-0"
        >
          {signatureConcepts.map((concept) => {
            const active = concept.id === activeSignature;
            return (
              <li
                key={concept.id}
                data-reveal-item
                className={cn(
                  "relative flex-none basis-[84%] snap-start sm:basis-[46%] lg:basis-0 lg:transition-[flex-grow] lg:duration-[900ms] lg:ease-[var(--ease-in-out-soft)]",
                  active ? "lg:grow-[2.3]" : "lg:grow",
                )}
                onMouseEnter={() => {
                  if (window.matchMedia("(hover: hover) and (min-width: 64rem)").matches) setActiveSignature(concept.id);
                }}
              >
                <article
                  id={`signature-${concept.id}`}
                  tabIndex={-1}
                  aria-labelledby={`signature-${concept.id}-title`}
                  className="group relative isolate flex h-full min-h-[440px] flex-col justify-end overflow-hidden rounded-[20px] bg-ink text-white sm:min-h-[460px] lg:min-h-0"
                >
                  <Image
                    src={concept.image.src}
                    alt={concept.image.alt}
                    fill
                    sizes="(min-width: 1024px) 720px, (min-width: 640px) 46vw, 84vw"
                    style={{ objectPosition: concept.image.position }}
                    className={cn(
                      "-z-10 object-cover transition-transform duration-[1400ms] ease-[var(--ease-out-expo)]",
                      active ? "lg:scale-100" : "lg:scale-[1.04]",
                    )}
                  />
                  <div
                    aria-hidden
                    className={cn(
                      "absolute inset-0 -z-10 bg-gradient-to-t from-ink/80 via-ink/25 to-ink/0 transition-opacity duration-700",
                      active ? "lg:opacity-100" : "lg:opacity-80",
                    )}
                  />

                  <div className="p-6 sm:p-7 lg:p-8">
                    <div className="flex items-center gap-3">
                      <span className="type-eyebrow text-peach">{concept.number}</span>
                      <span aria-hidden className="h-px w-8 bg-white/40" />
                    </div>
                    <h3
                      id={`signature-${concept.id}-title`}
                      className="mt-3 text-[1.375rem] leading-tight font-medium tracking-[-0.01em] lg:text-2xl"
                    >
                      {concept.title}
                    </h3>
                    <div
                      className={cn(
                        "grid transition-[grid-template-rows,opacity] duration-700 ease-[var(--ease-out-expo)]",
                        active ? "grid-rows-[1fr] opacity-100" : "grid-rows-[1fr] opacity-100 lg:grid-rows-[0fr] lg:opacity-0",
                      )}
                    >
                      <p className="max-w-[44ch] overflow-hidden pt-3 text-[15px] leading-relaxed text-white/85">
                        {concept.description}
                      </p>
                    </div>
                  </div>

                  {/* Desktop: keyboard / click activation */}
                  <button
                    type="button"
                    className="absolute inset-0 hidden cursor-pointer rounded-[20px] lg:block"
                    aria-expanded={active}
                    onClick={() => setActiveSignature(concept.id)}
                    onFocus={() => setActiveSignature(concept.id)}
                  >
                    <span className="sr-only">Zobraziť popis: {concept.title}</span>
                  </button>
                </article>
              </li>
            );
          })}
        </Reveal>

        <Reveal>
          <p className="mt-6 text-[13px] text-muted lg:mt-7">
            Koncepty LINA Signature nie sú pevne dané protokoly — konkrétny postup zostavíme individuálne po konzultácii.
          </p>
        </Reveal>
      </div>
    </section>
  );
}
