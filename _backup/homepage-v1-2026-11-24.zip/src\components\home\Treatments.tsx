"use client";

import Image from "next/image";
import { areas, treatmentGroups, type AreaId } from "@/data/treatments";
import { images } from "@/data/images";
import { Reveal } from "@/components/motion/Reveal";
import { SplitText } from "@/components/motion/SplitText";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { useHome } from "./HomeProvider";
import { cn } from "@/lib/cn";

const areaLabel = (id: AreaId) => areas.find((a) => a.id === id)?.shortLabel ?? id;

export function Treatments() {
  const { areaFilter, setAreaFilter, focusedGroup } = useHome();
  const filters: Array<{ id: AreaId | "all"; label: string }> = [
    { id: "all", label: "Všetky" },
    ...areas.map((a) => ({ id: a.id, label: a.shortLabel })),
  ];
  const matchCount =
    areaFilter === "all" ? treatmentGroups.length : treatmentGroups.filter((g) => g.areas.includes(areaFilter)).length;

  return (
    <section id="osetrenia" aria-labelledby="osetrenia-title" className="section-y border-t border-line">
      <div className="container-site">
        <header className="grid gap-x-10 gap-y-5 lg:grid-cols-12 lg:items-end">
          <div className="lg:col-span-7">
            <Reveal>
              <Eyebrow>Naše ošetrenia</Eyebrow>
            </Reveal>
            <SplitText as="h2" id="osetrenia-title" className="type-h2 mt-4">
              Starostlivosť <strong className="font-medium">podľa vašich potrieb.</strong>
            </SplitText>
          </div>
          <Reveal className="lg:col-span-5">
            <p className="max-w-[460px] text-muted">
              Prehľad oblastí, ktorým sa venujeme. Konkrétny postup vždy odporučíme až po osobnej konzultácii.
            </p>
          </Reveal>
        </header>

        {/* Area filter */}
        <Reveal className="mt-8 flex flex-wrap items-center justify-between gap-4 lg:mt-10">
          <div role="group" aria-label="Filtrovať podľa oblasti" className="no-scrollbar -mx-1 flex gap-1.5 overflow-x-auto px-1 py-1 sm:gap-2">
            {filters.map((f) => {
              const pressed = areaFilter === f.id;
              return (
                <button
                  key={f.id}
                  type="button"
                  aria-pressed={pressed}
                  onClick={() => setAreaFilter(f.id)}
                  className={cn(
                    "h-10 shrink-0 rounded-full border px-3.5 text-[13px] font-medium transition-[background-color,border-color,color] duration-300 sm:px-5",
                    pressed
                      ? "border-primary bg-primary text-white"
                      : "border-line bg-white text-ink/75 hover:border-ink/30 hover:text-ink",
                  )}
                >
                  {f.label}
                </button>
              );
            })}
          </div>
          <p className="text-[13px] text-muted" aria-live="polite">
            {areaFilter === "all" ? `${matchCount} oblastí starostlivosti` : `Zobrazené: ${matchCount} z ${treatmentGroups.length}`}
          </p>
        </Reveal>

        {/* Grid: portrait tile + six treatment groups */}
        <Reveal
          id="osetrenia-zoznam"
          mode="items"
          stagger={0.07}
          className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4 lg:gap-4"
        >
          <figure
            data-reveal-item
            className="relative isolate overflow-hidden rounded-[20px] bg-surface max-lg:aspect-[16/10] sm:col-span-2 lg:col-span-1 lg:row-span-2"
          >
            <Image
              src={images.portraitMan.src}
              alt={images.portraitMan.alt}
              fill
              sizes="(min-width: 1024px) 320px, 100vw"
              style={{ objectPosition: images.portraitMan.position }}
              className="object-cover"
            />
            <div aria-hidden className="absolute inset-0 bg-gradient-to-t from-ink/70 via-ink/10 to-transparent" />
            <figcaption className="absolute inset-x-0 bottom-0 p-5 text-white lg:p-6">
              <p className="type-eyebrow text-peach">Pre dámy aj pánov</p>
              <p className="mt-2 max-w-[28ch] text-[15px] leading-snug">
                Každé ošetrenie prispôsobujeme vašej pokožke, črtám a očakávaniam.
              </p>
            </figcaption>
          </figure>

          {treatmentGroups.map((group, i) => {
            const matches = areaFilter === "all" || group.areas.includes(areaFilter);
            const focused = focusedGroup === group.id;
            return (
              <article
                key={group.id}
                id={`osetrenie-${group.id}`}
                tabIndex={-1}
                data-reveal-item
                aria-labelledby={`osetrenie-${group.id}-title`}
                className={cn(
                  "group relative flex flex-col rounded-[20px] border p-6 transition-[opacity,background-color,border-color,box-shadow,transform] duration-500 ease-[var(--ease-out-expo)] lg:p-7",
                  matches
                    ? "border-transparent bg-surface hover:-translate-y-0.5 hover:border-line hover:bg-white hover:shadow-[0_20px_40px_-28px_rgb(36_36_36/0.35)]"
                    : "border-transparent bg-surface opacity-35",
                  focused && "border-primary/40 bg-white [animation:focus-ring_1.2s_ease-out_2]",
                )}
              >
                <div className="flex items-center justify-between gap-3">
                  <span className="text-[13px] font-medium text-muted tabular-nums">0{i + 1}</span>
                  <ul className="flex flex-wrap justify-end gap-1.5" aria-label="Oblasti">
                    {group.areas.map((a) => (
                      <li
                        key={a}
                        className={cn(
                          "rounded-full px-2.5 py-1 text-[11px] font-medium transition-colors duration-300",
                          areaFilter === a ? "bg-primary text-white" : "bg-white text-ink/70 ring-1 ring-line",
                        )}
                      >
                        {areaLabel(a)}
                      </li>
                    ))}
                  </ul>
                </div>
                <h3 id={`osetrenie-${group.id}-title`} className="mt-6 text-card font-medium tracking-[-0.01em]">
                  {group.title}
                </h3>
                <p className="mt-2 text-small text-muted">{group.description}</p>
                <div className="mt-auto pt-5">
                  <p className="text-[11px] font-semibold tracking-[0.14em] text-ink/60 uppercase">{group.listLabel}</p>
                  <ul className="mt-2 flex flex-wrap gap-x-1.5 gap-y-1.5">
                    {group.items.map((item) => (
                      <li
                        key={item}
                        className="rounded-md bg-white px-2 py-1 text-[12.5px] leading-tight text-ink/85 ring-1 ring-line transition-colors group-hover:ring-peach-line"
                      >
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </article>
            );
          })}
        </Reveal>
      </div>
    </section>
  );
}
