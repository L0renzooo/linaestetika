/**
 * Homepage-only navigation. Every entry is a working in-page anchor.
 * When the future routes (/damy, /pani, /cennik, /kontakt …) exist,
 * switch these hrefs to the real pages.
 */
export type NavItem = { label: string; href: `#${string}`; sectionId: string };

export const mainNav: NavItem[] = [
  { label: "Ošetrenia", href: "#osetrenia", sectionId: "osetrenia" },
  { label: "LINA Signature", href: "#signature", sectionId: "signature" },
  { label: "Náš prístup", href: "#pristup", sectionId: "pristup" },
  { label: "Kontakt", href: "#kontakt", sectionId: "kontakt" },
];
