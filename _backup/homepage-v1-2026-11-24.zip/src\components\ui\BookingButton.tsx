"use client";

import { isBookingConfigured, siteConfig } from "@/config/site";
import { buttonClass, type ButtonSize, type ButtonVariant } from "./buttonStyles";
import { ArrowIcon } from "./icons";

export const BOOKING_PENDING_EVENT = "lina:booking-pending";

type BookingButtonProps = {
  variant?: ButtonVariant;
  size?: ButtonSize;
  className?: string;
  withIcon?: boolean;
  onNavigate?: () => void;
};

/**
 * The ONLY booking action on the site. All instances read the same Bookio URL
 * from siteConfig. While the URL is empty, the button stays a <button> that
 * announces the pending state instead of navigating anywhere.
 */
export function BookingButton({ variant = "primary", size = "md", className, withIcon = true, onNavigate }: BookingButtonProps) {
  const label = siteConfig.bookingLabel;
  const icon = withIcon ? (
    <ArrowIcon className="size-4 transition-transform duration-300 group-hover/btn:translate-x-0.5" />
  ) : null;

  if (isBookingConfigured) {
    return (
      <a
        href={siteConfig.bookingUrl}
        target="_blank"
        rel="noopener"
        className={buttonClass(variant, size, className)}
        onClick={onNavigate}
      >
        {label}
        <span className="sr-only"> (otvorí sa v novom okne)</span>
        {icon}
      </a>
    );
  }

  return (
    <button
      type="button"
      className={buttonClass(variant, size, className)}
      aria-describedby="booking-pending-description"
      data-booking-pending=""
      onClick={() => {
        onNavigate?.();
        window.dispatchEvent(new CustomEvent(BOOKING_PENDING_EVENT));
      }}
    >
      {label}
      {icon}
    </button>
  );
}
