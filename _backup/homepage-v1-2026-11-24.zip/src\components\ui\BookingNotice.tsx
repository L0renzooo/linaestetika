"use client";

import { useEffect, useRef, useState } from "react";
import { isBookingConfigured } from "@/config/site";
import { BOOKING_PENDING_EVENT } from "./BookingButton";
import { CloseIcon } from "./icons";
import { cn } from "@/lib/cn";

/**
 * Accessible notice shown while the Bookio URL is not configured yet.
 * Renders nothing once siteConfig.bookingUrl is filled in.
 */
export function BookingNotice() {
  const [open, setOpen] = useState(false);
  const timer = useRef<number | undefined>(undefined);

  useEffect(() => {
    if (isBookingConfigured) return;
    const show = () => {
      setOpen(true);
      window.clearTimeout(timer.current);
      timer.current = window.setTimeout(() => setOpen(false), 6000);
    };
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener(BOOKING_PENDING_EVENT, show);
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener(BOOKING_PENDING_EVENT, show);
      window.removeEventListener("keydown", onKey);
      window.clearTimeout(timer.current);
    };
  }, []);

  if (isBookingConfigured) return null;

  return (
    <>
      <p id="booking-pending-description" className="sr-only">
        Online rezervácia cez Bookio bude čoskoro dostupná.
      </p>
      <div
        role="status"
        aria-live="polite"
        className={cn(
          "fixed inset-x-4 bottom-4 z-[60] mx-auto flex max-w-md items-start gap-4 rounded-2xl border border-line bg-white p-4 pr-3 shadow-[0_24px_60px_-20px_rgb(36_36_36/0.35)] transition-[opacity,transform] duration-500 ease-[var(--ease-out-expo)] sm:inset-x-auto sm:right-6 sm:bottom-6",
          open ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-4 opacity-0",
        )}
      >
        {open && (
          <>
            <span className="mt-1.5 size-2 shrink-0 rounded-full bg-primary" aria-hidden />
            <div className="flex-1 text-sm leading-relaxed">
              <p className="font-medium">Online rezervácia sa pripravuje</p>
              <p className="text-muted">
                Rezervačný systém Bookio spustíme čoskoro. Ďakujeme za trpezlivosť.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="grid size-9 shrink-0 place-items-center rounded-full text-muted transition-colors hover:bg-surface hover:text-ink"
              aria-label="Zavrieť oznámenie"
            >
              <CloseIcon className="size-4" />
            </button>
          </>
        )}
      </div>
    </>
  );
}
