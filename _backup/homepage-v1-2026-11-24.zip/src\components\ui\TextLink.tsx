import type { ReactNode, AnchorHTMLAttributes } from "react";
import { cn } from "@/lib/cn";

/** Understated text link with an animated underline. */
export function TextLink({
  children,
  className,
  icon,
  ...rest
}: { children: ReactNode; icon?: ReactNode } & AnchorHTMLAttributes<HTMLAnchorElement>) {
  return (
    <a
      className={cn(
        "group/link inline-flex min-h-11 items-center gap-2 text-sm font-medium text-ink transition-colors hover:text-primary",
        className,
      )}
      {...rest}
    >
      <span className="relative">
        {children}
        <span
          aria-hidden
          className="absolute -bottom-0.5 left-0 h-px w-full origin-left bg-current transition-transform duration-500 ease-[var(--ease-out-expo)] group-hover/link:scale-x-0"
        />
      </span>
      {icon}
    </a>
  );
}
