/**
 * Central site configuration.
 *
 * bookingUrl — paste the client's Bookio URL here once it is available.
 * While it is empty, every "Rezervovať termín" button renders a clearly
 * marked pending state instead of navigating anywhere.
 */
export const siteConfig = {
  name: "LINA ESTETIKA",
  url: "", // production domain, e.g. "https://www.linaestetika.sk" — fill in before launch
  bookingUrl: "",
  bookingLabel: "Rezervovať termín",
  description:
    "Estetická medicína v Senci. Individuálna starostlivosť o kvalitu pokožky, hydratáciu a prirodzený vzhľad — s osobným prístupom ku každému klientovi.",
  address: {
    street: "Mierové námestie 11",
    city: "Senec",
    country: "Slovensko",
    countryCode: "SK",
  },
  openingHours: [{ days: "Pondelok – Sobota", hours: "podľa objednávok" }],
  phone: "", // not available yet — do not invent
  email: "", // not available yet
} as const;

export const fullAddress = `${siteConfig.address.street}, ${siteConfig.address.city}, ${siteConfig.address.country}`;

export const mapsDirectionsUrl = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(
  `${siteConfig.address.street}, ${siteConfig.address.city}, Slovakia`,
)}`;

export const isBookingConfigured = siteConfig.bookingUrl.trim().length > 0;
