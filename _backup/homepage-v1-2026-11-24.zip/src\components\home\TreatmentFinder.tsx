"use client";

import Image from "next/image";
import { useLayoutEffect, useRef, useState, type KeyboardEvent } from "react";
import { areas, finderEntries, type AreaId, type FinderEntry } from "@/data/treatments";
import { gsap, motion, useGSAP } from "@/components/motion/gsap";
import { ArrowIcon } from "@/components/ui/icons";
import { useHome } from "./HomeProvider";
import { cn } from "@/lib/cn";

/**
 * Hero treatment finder: choose a body area → the photograph changes and a
 * short list of relevant treatments appears. Each entry jumps to the matching
 * card in the overview (pre-filtered) or to the LINA Signature concept.
 */
export function TreatmentFinder() {
  const { showGroup, showSignature } = useHome();
  const [areaId, setAreaId] = useState<AreaId>("tvar");
  const tabRefs = useRef<Record<string, HTMLButtonElement | null>>({});
  const tablistRef = useRef<HTMLDivElement>(null);
  const indicatorRef = useRef<HTMLSpanElement>(null);
  const listRef = useRef<HTMLUListElement>(null);
  const firstRender = useRef(true);

  const activeIndex = areas.findIndex((a) => a.id === areaId);
  const area = areas[activeIndex];
  const entries = finderEntries[areaId];

  // Sliding pill indicator behind the active tab.
  useLayoutEffect(() => {
    const place = () => {
      const tab = tabRefs.current[areaId];
      const ind = indicatorRef.current;
      if (!tab || !ind) return;
      ind.style.width = `${tab.offsetWidth}px`;
      ind.style.transform = `translateX(${tab.offsetLeft}px)`;
    };
    place();
    const ro = new ResizeObserver(place);
    if (tablistRef.current) ro.observe(tablistRef.current);
    return () => ro.disconnect();
  }, [areaId]);

  // Gentle stagger when the list content changes (not on first paint).
  useGSAP(
    () => {
      if (firstRender.current) {
        firstRender.current = false;
        return;
      }
      const mm = gsap.matchMedia();
      mm.add(motion.allowMotion, () => {
        gsap.from("li", { autoAlpha: 0, y: 10, duration: 0.55, stagger: 0.05, ease: motion.ease, clearProps: "all" });
      });
    },
    { scope: listRef, dependencies: [areaId] },
  );

  const onTabKey = (e: KeyboardEvent<HTMLButtonElement>) => {
    const keys = ["ArrowRight", "ArrowLeft", "Home", "End"];
    if (!keys.includes(e.key)) return;
    e.preventDefault();
    let next = activeIndex;
    if (e.key === "ArrowRight") next = (activeIndex + 1) % areas.length;
    if (e.key === "ArrowLeft") next = (activeIndex - 1 + areas.length) % areas.length;
    if (e.key === "Home") next = 0;
    if (e.key === "End") next = areas.length - 1;
    setAreaId(areas[next].id);
    tabRefs.current[areas[next].id]?.focus();
  };

  const open = (entry: FinderEntry) => {
    if (entry.kind === "group") showGroup(entry.groupId, areaId);
    else showSignature(entry.signatureId);
  };

  return (
    <div className="grid gap-4 lg:grid-cols-12 lg:gap-5">
      {/* Photograph */}
      <div
        data-hero-media
        className="relative aspect-[4/3] overflow-hidden rounded-[20px] bg-peach-soft sm:aspect-[16/10] lg:col-span-7 lg:aspect-auto lg:min-h-[556px]"
      >
        <div data-hero-media-inner className="absolute inset-0">
          {areas.map((a, i) => {
            const isActive = a.id === areaId;
            return (
              <Image
                key={a.id}
                src={a.image.src}
                alt={isActive ? a.image.alt : ""}
                aria-hidden={!isActive}
                fill
                priority={i === 0}
                sizes="(min-width: 1440px) 760px, (min-width: 1024px) 56vw, 100vw"
                style={{ objectPosition: a.image.position }}
                className={cn(
                  "object-cover transition-[opacity,transform] duration-[1400ms] ease-[var(--ease-out-expo)]",
                  isActive ? "scale-100 opacity-100" : "scale-[1.06] opacity-0",
                )}
              />
            );
          })}
        </div>
        <div
          aria-hidden
          className="pointer-events-none absolute inset-x-0 bottom-0 h-1/3 bg-gradient-to-t from-ink/25 to-transparent"
        />
        <div className="absolute right-4 bottom-4 left-4 flex sm:right-auto sm:bottom-5 sm:left-5">
          <p className="flex items-center gap-3 rounded-full bg-white/85 py-1.5 pr-4 pl-1.5 text-[13px] backdrop-blur-md">
            <span className="grid size-7 shrink-0 place-items-center rounded-full bg-primary text-[11px] font-semibold text-white tabular-nums">
              0{activeIndex + 1}
            </span>
            <span className="font-medium">{area.label}</span>
            <span aria-hidden className="hidden h-3 w-px bg-ink/20 md:block" />
            <span className="hidden text-ink/70 md:block">{area.intro}</span>
          </p>
        </div>
      </div>

      {/* Finder panel */}
      <div
        data-hero-panel
        data-reveal="self"
        className="flex flex-col rounded-[20px] border border-line bg-white p-5 sm:p-7 lg:col-span-5 lg:px-8 lg:py-7"
      >
        <div>
          <h2 className="text-[1.375rem] leading-tight font-medium tracking-[-0.01em]">Čo vás zaujíma?</h2>
          <p className="mt-1.5 text-small text-muted">Vyberte oblasť a pozrite si vhodné ošetrenia.</p>
        </div>

        <div
          ref={tablistRef}
          role="tablist"
          aria-label="Oblasť ošetrenia"
          className="relative mt-5 flex rounded-full bg-surface p-1"
        >
          <span
            ref={indicatorRef}
            aria-hidden
            className="absolute top-1 bottom-1 left-0 rounded-full bg-primary shadow-[0_6px_16px_-8px_rgb(216_69_87/0.8)] transition-[transform,width] duration-500 ease-[var(--ease-out-expo)]"
          />
          {areas.map((a) => {
            const selected = a.id === areaId;
            return (
              <button
                key={a.id}
                ref={(el) => {
                  tabRefs.current[a.id] = el;
                }}
                type="button"
                role="tab"
                id={`finder-tab-${a.id}`}
                aria-selected={selected}
                aria-controls="finder-panel"
                tabIndex={selected ? 0 : -1}
                onClick={() => setAreaId(a.id)}
                onKeyDown={onTabKey}
                className={cn(
                  "relative z-10 h-10 flex-1 rounded-full px-2 text-[13px] font-medium transition-colors duration-300 sm:text-sm",
                  selected ? "text-white" : "text-ink/70 hover:text-ink",
                )}
              >
                {a.shortLabel}
              </button>
            );
          })}
        </div>

        <div id="finder-panel" role="tabpanel" aria-labelledby={`finder-tab-${areaId}`} className="mt-4 flex flex-1 flex-col">
          <p className="sr-only">{area.intro}</p>
          <ul ref={listRef} className="divide-y divide-line border-b border-line">
            {entries.map((entry) => (
              <li key={`${areaId}-${entry.title}`}>
                <button
                  type="button"
                  onClick={() => open(entry)}
                  className="group flex min-h-[54px] w-full items-center gap-4 py-2.5 text-left transition-colors"
                >
                  <span className="flex-1">
                    <span className="flex flex-wrap items-center gap-x-2 gap-y-1 text-[15px] leading-snug font-medium transition-colors group-hover:text-primary">
                      {entry.title}
                      {entry.kind === "signature" && (
                        <span className="rounded-full bg-peach-soft px-2 py-0.5 text-[10px] font-semibold tracking-[0.12em] text-ink uppercase ring-1 ring-peach-line">
                          Signature
                        </span>
                      )}
                    </span>
                    {entry.kind === "group" && (
                      <span className="mt-0.5 block text-[13px] leading-snug text-muted">{entry.detail}</span>
                    )}
                  </span>
                  <span className="grid size-9 shrink-0 place-items-center rounded-full border border-line text-ink transition-[background-color,border-color,color,transform] duration-300 group-hover:translate-x-0.5 group-hover:border-primary group-hover:bg-primary group-hover:text-white">
                    <ArrowIcon className="size-4" />
                  </span>
                </button>
              </li>
            ))}
          </ul>
          <p className="mt-auto pt-4 text-[13px] leading-relaxed text-muted">
            Nie ste si istí výberom? Vhodný postup vám odporučíme pri osobnej konzultácii.
          </p>
        </div>
      </div>
    </div>
  );
}
