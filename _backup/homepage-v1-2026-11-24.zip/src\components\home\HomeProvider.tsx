"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import type { AreaId } from "@/data/treatments";
import { signatureConcepts } from "@/data/signature";
import { scrollToTarget } from "@/lib/scroll";

/**
 * Shared homepage state so the hero treatment finder can drive the
 * treatment overview and the LINA Signature section.
 */
type AreaFilter = AreaId | "all";

type HomeContextValue = {
  areaFilter: AreaFilter;
  setAreaFilter: (area: AreaFilter) => void;
  focusedGroup: string | null;
  showGroup: (groupId: string, area?: AreaId) => void;
  activeSignature: string;
  setActiveSignature: (id: string) => void;
  showSignature: (id: string) => void;
};

const HomeContext = createContext<HomeContextValue | null>(null);

export function HomeProvider({ children }: { children: ReactNode }) {
  const [areaFilter, setAreaFilter] = useState<AreaFilter>("all");
  const [focusedGroup, setFocusedGroup] = useState<string | null>(null);
  const [activeSignature, setActiveSignature] = useState(signatureConcepts[0].id);
  const focusTimer = useRef<number | undefined>(undefined);

  useEffect(() => () => window.clearTimeout(focusTimer.current), []);

  const showGroup = useCallback((groupId: string, area?: AreaId) => {
    if (area) setAreaFilter(area);
    setFocusedGroup(groupId);
    window.clearTimeout(focusTimer.current);
    focusTimer.current = window.setTimeout(() => setFocusedGroup(null), 2400);

    const isMobile = window.matchMedia("(max-width: 767px)").matches;
    const card = document.getElementById(`osetrenie-${groupId}`);
    const grid = document.getElementById("osetrenia-zoznam");
    const target = isMobile ? card : grid;
    if (target) scrollToTarget(target, { extraOffset: 20, focus: false });
    // Move keyboard focus to the card itself so screen-reader users land on it.
    card?.focus({ preventScroll: true });
  }, []);

  const showSignature = useCallback((id: string) => {
    setActiveSignature(id);
    const isDesktop = window.matchMedia("(min-width: 64rem)").matches;
    const target = isDesktop ? document.getElementById("signature") : document.getElementById(`signature-${id}`);
    if (target) scrollToTarget(target, { extraOffset: isDesktop ? 0 : 20, focus: false });
    document.getElementById(`signature-${id}`)?.focus({ preventScroll: true });
  }, []);

  const value = useMemo(
    () => ({ areaFilter, setAreaFilter, focusedGroup, showGroup, activeSignature, setActiveSignature, showSignature }),
    [areaFilter, focusedGroup, showGroup, activeSignature, showSignature],
  );

  return <HomeContext.Provider value={value}>{children}</HomeContext.Provider>;
}

export function useHome() {
  const ctx = useContext(HomeContext);
  if (!ctx) throw new Error("useHome must be used inside <HomeProvider>");
  return ctx;
}
