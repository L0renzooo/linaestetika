import { fullAddress, mapsDirectionsUrl, siteConfig } from "@/config/site";
import { mainNav } from "@/data/navigation";
import { Logo } from "@/components/ui/Logo";

export function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="border-t border-line">
      <div className="container-site grid gap-10 py-12 sm:grid-cols-2 lg:grid-cols-12 lg:py-14">
        <div className="lg:col-span-5">
          <Logo className="w-[96px]" />
          <p className="mt-5 max-w-[34ch] text-small text-muted">
            Estetická medicína v Senci. Individuálna starostlivosť s dôrazom na prirodzený vzhľad.
          </p>
        </div>

        <nav aria-label="Navigácia v pätičke" className="lg:col-span-3">
          <p className="text-[11px] font-semibold tracking-[0.14em] text-ink/60 uppercase">Stránka</p>
          <ul className="mt-3 space-y-1">
            {mainNav.map((item) => (
              <li key={item.href}>
                <a href={item.href} className="inline-flex min-h-9 items-center text-[15px] transition-colors hover:text-primary">
                  {item.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div className="lg:col-span-4">
          <p className="text-[11px] font-semibold tracking-[0.14em] text-ink/60 uppercase">Navštívte nás</p>
          <address className="mt-3 text-[15px] leading-relaxed not-italic">
            {siteConfig.address.street}
            <br />
            {siteConfig.address.city}, {siteConfig.address.country}
          </address>
          <a
            href={mapsDirectionsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-2 inline-flex min-h-9 items-center text-[15px] font-medium underline decoration-ink/25 underline-offset-4 transition-colors hover:text-primary hover:decoration-primary"
          >
            Zobraziť na mape
            <span className="sr-only"> — {fullAddress} (otvorí sa v novom okne)</span>
          </a>
          <p className="mt-3 text-[15px] text-muted">
            {siteConfig.openingHours[0].days}: {siteConfig.openingHours[0].hours}
          </p>
        </div>
      </div>

      <div className="container-site flex flex-col gap-2 border-t border-line py-6 text-[13px] text-muted sm:flex-row sm:items-center sm:justify-between">
        <p>
          © {year} {siteConfig.name}. Všetky práva vyhradené.
        </p>
        <p>Fotografie na webe sú ilustračné.</p>
      </div>
    </footer>
  );
}
