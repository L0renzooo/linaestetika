import { HomeProvider } from "@/components/home/HomeProvider";
import { Hero } from "@/components/home/Hero";
import { Treatments } from "@/components/home/Treatments";
import { Signature } from "@/components/home/Signature";
import { Approach } from "@/components/home/Approach";
import { Contact } from "@/components/home/Contact";

/**
 * Homepage — iteration 1.
 * Results gallery and reviews are intentionally omitted until approved
 * before/after pairs and verified Bookio reviews are available.
 */
export default function HomePage() {
  return (
    <HomeProvider>
      <Hero />
      <Treatments />
      <Signature />
      <Approach />
      <Contact />
    </HomeProvider>
  );
}
