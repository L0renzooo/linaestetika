"use client";

import { useEffect, useId, useRef, useState } from "react";
import { mainNav } from "@/data/navigation";
import { BookingButton } from "@/components/ui/BookingButton";
import { Logo } from "@/components/ui/Logo";
import { cn } from "@/lib/cn";

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [active, setActive] = useState<string | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const menuId = useId();
  const toggleRef = useRef<HTMLButtonElement>(null);

  // Elevated header once the page has scrolled.
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Highlight the section currently in view.
  useEffect(() => {
    const sections = mainNav
      .map((item) => document.getElementById(item.sectionId))
      .filter((el): el is HTMLElement => Boolean(el));
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) setActive(entry.target.id);
        });
      },
      { rootMargin: "-45% 0px -50% 0px" },
    );
    sections.forEach((s) => observer.observe(s));
    const onTop = () => window.scrollY < 200 && setActive(null);
    window.addEventListener("scroll", onTop, { passive: true });
    return () => {
      observer.disconnect();
      window.removeEventListener("scroll", onTop);
    };
  }, []);

  // Close the mobile menu with Escape / on desktop resize.
  useEffect(() => {
    if (!menuOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setMenuOpen(false);
        toggleRef.current?.focus();
      }
    };
    const mq = window.matchMedia("(min-width: 64rem)");
    const onMq = () => mq.matches && setMenuOpen(false);
    window.addEventListener("keydown", onKey);
    mq.addEventListener("change", onMq);
    return () => {
      window.removeEventListener("keydown", onKey);
      mq.removeEventListener("change", onMq);
    };
  }, [menuOpen]);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-[background-color,box-shadow,border-color] duration-500",
        scrolled || menuOpen
          ? "border-b border-line/80 bg-white/90 backdrop-blur-xl supports-[backdrop-filter]:bg-white/80"
          : "border-b border-transparent bg-white",
      )}
    >
      <a
        href="#obsah"
        className="sr-only z-[70] rounded-full bg-ink px-4 py-2 text-sm text-white focus:not-sr-only focus:absolute focus:top-3 focus:left-3"
      >
        Preskočiť na obsah
      </a>
      <div className="container-site flex h-[var(--header-h)] items-center justify-between gap-6">
        <a href="#" className="-ml-1 flex shrink-0 items-center rounded-md p-1" aria-label="LINA ESTETIKA — na začiatok stránky">
          <Logo priority className="w-[84px] lg:w-[96px]" />
        </a>

        <nav aria-label="Hlavná navigácia" className="hidden lg:block">
          <ul className="flex items-center gap-1">
            {mainNav.map((item) => {
              const isActive = active === item.sectionId;
              return (
                <li key={item.href}>
                  <a
                    href={item.href}
                    aria-current={isActive ? "location" : undefined}
                    className={cn(
                      "group relative inline-flex h-10 items-center px-4 text-sm font-medium transition-colors",
                      isActive ? "text-ink" : "text-ink/70 hover:text-ink",
                    )}
                  >
                    {item.label}
                    <span
                      aria-hidden
                      className={cn(
                        "absolute inset-x-4 bottom-1 h-[1.5px] origin-left rounded-full bg-primary transition-transform duration-500 ease-[var(--ease-out-expo)]",
                        isActive ? "scale-x-100" : "scale-x-0 group-hover:scale-x-100",
                      )}
                    />
                  </a>
                </li>
              );
            })}
          </ul>
        </nav>

        <div className="flex items-center gap-2">
          <BookingButton size="sm" withIcon={false} className="max-[379px]:px-4 max-[379px]:text-[12px]" />
          <button
            ref={toggleRef}
            type="button"
            className="relative grid size-10 place-items-center rounded-full border border-line lg:hidden"
            aria-expanded={menuOpen}
            aria-controls={menuId}
            aria-label={menuOpen ? "Zavrieť menu" : "Otvoriť menu"}
            onClick={() => setMenuOpen((o) => !o)}
          >
            <span aria-hidden className="relative block h-3 w-4">
              <span
                className={cn(
                  "absolute left-0 h-[1.5px] w-4 rounded bg-ink transition-transform duration-300",
                  menuOpen ? "top-1/2 -translate-y-1/2 rotate-45" : "top-0.5",
                )}
              />
              <span
                className={cn(
                  "absolute left-0 h-[1.5px] w-4 rounded bg-ink transition-transform duration-300",
                  menuOpen ? "top-1/2 -translate-y-1/2 -rotate-45" : "bottom-0.5",
                )}
              />
            </span>
          </button>
        </div>
      </div>

      {/* Mobile / tablet menu */}
      <div
        id={menuId}
        hidden={!menuOpen}
        className="border-t border-line bg-white lg:hidden"
      >
        <nav aria-label="Mobilná navigácia" className="container-site py-4">
          <ul className="divide-y divide-line">
            {mainNav.map((item) => (
              <li key={item.href}>
                <a
                  href={item.href}
                  onClick={() => setMenuOpen(false)}
                  className="flex min-h-13 items-center justify-between py-3 text-[15px] font-medium"
                >
                  {item.label}
                  <span aria-hidden className="text-muted">→</span>
                </a>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </header>
  );
}
