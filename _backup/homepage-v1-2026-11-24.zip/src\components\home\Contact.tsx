import { fullAddress, mapsDirectionsUrl, siteConfig } from "@/config/site";
import { Reveal } from "@/components/motion/Reveal";
import { SplitText } from "@/components/motion/SplitText";
import { BookingButton } from "@/components/ui/BookingButton";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Logo } from "@/components/ui/Logo";
import { buttonClass } from "@/components/ui/buttonStyles";
import { ArrowUpRightIcon, CalendarIcon, ClockIcon, PinIcon } from "@/components/ui/icons";

export function Contact() {
  return (
    <section id="kontakt" aria-labelledby="kontakt-title" className="section-y pt-0">
      <div className="container-site">
        <Reveal className="grid overflow-hidden rounded-[24px] bg-surface lg:grid-cols-12">
          <div className="p-6 sm:p-10 lg:col-span-7 lg:p-14">
            <Eyebrow>Kontakt</Eyebrow>
            <SplitText as="h2" id="kontakt-title" className="type-h2 mt-4">
              Tešíme sa <em className="font-extralight text-primary italic">na vás.</em>
            </SplitText>

            <dl className="mt-8 grid gap-6 sm:grid-cols-2 sm:gap-8">
              <div className="flex gap-3.5">
                <PinIcon className="mt-0.5 size-5 shrink-0 text-primary" />
                <div>
                  <dt className="text-[11px] font-semibold tracking-[0.14em] text-ink/60 uppercase">Adresa</dt>
                  <dd className="mt-1.5 text-[15px] leading-relaxed">
                    {siteConfig.name}
                    <br />
                    {siteConfig.address.street}
                    <br />
                    {siteConfig.address.city}, {siteConfig.address.country}
                  </dd>
                </div>
              </div>
              <div className="flex gap-3.5">
                <ClockIcon className="mt-0.5 size-5 shrink-0 text-primary" />
                <div>
                  <dt className="text-[11px] font-semibold tracking-[0.14em] text-ink/60 uppercase">Otváracie hodiny</dt>
                  {siteConfig.openingHours.map((row) => (
                    <dd key={row.days} className="mt-1.5 text-[15px] leading-relaxed">
                      {row.days}
                      <br />
                      <span className="text-muted">{row.hours}</span>
                    </dd>
                  ))}
                </div>
              </div>
              <div className="flex gap-3.5 sm:col-span-2">
                <CalendarIcon className="mt-0.5 size-5 shrink-0 text-primary" />
                <div>
                  <dt className="text-[11px] font-semibold tracking-[0.14em] text-ink/60 uppercase">Rezervácie</dt>
                  <dd className="mt-1.5 text-[15px] leading-relaxed">Online cez rezervačný systém Bookio.</dd>
                </div>
              </div>
            </dl>

            <div className="mt-9 flex flex-wrap gap-3">
              <BookingButton />
              <a
                href={mapsDirectionsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className={buttonClass("outline", "md")}
              >
                Navigovať
                <span className="sr-only"> na adresu {fullAddress} v Mapách Google (otvorí sa v novom okne)</span>
                <ArrowUpRightIcon className="size-4" />
              </a>
            </div>
          </div>

          {/* Brand panel */}
          <div className="relative flex min-h-[260px] flex-col items-center justify-center gap-6 bg-primary p-10 text-center text-white lg:col-span-5 lg:min-h-0">
            <Logo variant="peach" className="w-[180px] sm:w-[220px]" />
            <p className="max-w-[26ch] text-[15px] leading-relaxed text-white/90">
              {siteConfig.address.street}
              <br />
              {siteConfig.address.city}
            </p>
            <span aria-hidden className="absolute inset-4 rounded-[18px] border border-white/15" />
          </div>
        </Reveal>
      </div>
    </section>
  );
}
